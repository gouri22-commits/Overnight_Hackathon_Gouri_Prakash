"""
streamlit_app.py
Run with: streamlit run streamlit_app.py
Simple demo dashboard for flagged transactions.
"""
import streamlit as st
import pandas as pd

st.title("Agricultural Subsidy Leakage Detection — Demo")
st.markdown("Upload datasets or use bundled demo data to see flagged transactions.")

@st.cache_data
def load_demo():
    tx = pd.read_csv("data/transactions.csv", parse_dates=["date"])
    farmers = pd.read_csv("data/farmers.csv")
    regions = pd.read_csv("data/regions.csv")
    return tx, farmers, regions

tx, farmers, regions = load_demo()
st.write("Transactions sample:")
st.dataframe(tx.head(10))

st.sidebar.header("Filter")
districts = sorted(tx['dealer_id'].unique().tolist())[:20]
st.sidebar.selectbox("Dealer", options=["All"] + districts)
