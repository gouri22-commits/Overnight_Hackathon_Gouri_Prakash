# Agricultural Input Subsidy Leakage Detection System

This repository is a starter kit for building an anomaly-detection pipeline to flag suspicious subsidy transactions.

**Contents**
- `data/` - synthetic example datasets (transactions, farmers, dealers, regions)
- `notebooks/` - example notebooks for data prep, features, and anomaly detection
- `src/` - helper modules for loading data, feature engineering, model training
- `dashboard/` - streamlit app stub
- `README.md` - this file

**How to run**
1. Open `notebooks/01_data_preparation.ipynb` in Jupyter or Colab to inspect data.
2. Run `notebooks/02_feature_engineering.ipynb` to compute features.
3. Run `notebooks/03_anomaly_detection.ipynb` to train an IsolationForest on features.
4. (Optional) `streamlit run dashboard/streamlit_app.py` to start a simple demo dashboard.

This repo was auto-generated on 2025-12-04T18:36:52.588117 (UTC).
