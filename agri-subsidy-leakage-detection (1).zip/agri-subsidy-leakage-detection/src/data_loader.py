"""
data_loader.py
Simple functions to load datasets for the project.
"""
import pandas as pd
import os

ROOT = os.path.join(os.path.dirname(__file__), "..", "data")

def load_transactions(path=None):
    if path is None:
        path = os.path.join(ROOT, "transactions.csv")
    return pd.read_csv(path, parse_dates=["date"])

def load_farmers(path=None):
    if path is None:
        path = os.path.join(ROOT, "farmers.csv")
    return pd.read_csv(path)

def load_dealers(path=None):
    if path is None:
        path = os.path.join(ROOT, "dealers.csv")
    return pd.read_csv(path)

def load_regions(path=None):
    if path is None:
        path = os.path.join(ROOT, "regions.csv")
    return pd.read_csv(path)
