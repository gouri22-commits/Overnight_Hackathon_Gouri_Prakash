"""
anomaly_model.py
Train and score an IsolationForest model on engineering features.
"""
import numpy as np
from sklearn.ensemble import IsolationForest
import joblib

def train_isolationforest(X, contamination=0.05, random_state=42):
    model = IsolationForest(n_estimators=200, contamination=contamination, random_state=random_state)
    model.fit(X)
    return model

def save_model(model, path):
    joblib.dump(model, path)

def load_model(path):
    return joblib.load(path)

def score_model(model, X):
    labels = model.predict(X)
    scores = -model.decision_function(X)
    return labels, scores
