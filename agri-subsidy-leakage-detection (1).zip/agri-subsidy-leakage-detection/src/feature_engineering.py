"""
feature_engineering.py
Basic feature engineering utilities for the pipeline.
"""
import pandas as pd
import numpy as np

def add_expected_and_ratio(df, farmers, regions):
    df = df.merge(farmers[['farmer_id','land_area_hectares','district']], on='farmer_id', how='left')
    df = df.merge(regions, left_on=['district','input_type'], right_on=['district','input_type'], how='left')
    df['expected_qty'] = df['land_area_hectares'] * df['expected_qty_per_hectare']
    df['consumption_ratio'] = df['quantity'] / df['expected_qty'].replace(0, np.nan)
    df['consumption_ratio'] = df['consumption_ratio'].fillna(9999)
    # off-season
    df['planting_start'] = pd.to_datetime(df['planting_start'])
    df['planting_end'] = pd.to_datetime(df['planting_end'])
    df['off_season'] = (~((df['date'] >= df['planting_start']) & (df['date'] <= df['planting_end']))).astype(int)
    return df
